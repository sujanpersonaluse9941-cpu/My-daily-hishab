My Daily Hisab — Android Studio Project

এটি একটি প্রাথমিক Android হিসাব অ্যাপের সোর্স প্রজেক্ট। এতে আয়/খরচ যোগ, বিবরণ, ক্যাটাগরি, Cash/Digital নির্বাচন, মোট আয়/খরচ/ব্যালেন্স এবং ডিভাইসে DataStore-এ তথ্য সংরক্ষণ আছে। বাংলা/ইংরেজি লেবেল বদলানো যায়।

গুরুত্বপূর্ণ: এই সোর্স প্রজেক্টটি এখানে Android SDK দিয়ে build বা ফোনে test করা হয়নি। এটি APK নয়। GitHub Actions দিয়ে APK বানানোর জন্য আলাদা workflow GitHub repository-তে যোগ করতে হবে।
