package com.sujan.mydailyhisab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val android.content.Context.dataStore by preferencesDataStore(name = "hisab_store")
private val Navy = Color(0xFF101B35)
private val Gold = Color(0xFFD6A84F)
private val Income = Color(0xFF16865B)
private val Expense = Color(0xFFC44747)

data class Entry(val id: Long, val title: String, val amount: Double, val type: String, val category: String, val payment: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HisabApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HisabApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var entries by remember { mutableStateOf(listOf<Entry>()) }
    var loaded by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var type by remember { mutableStateOf("Expense") }
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Other") }
    var payment by remember { mutableStateOf("Cash") }
    var bengali by remember { mutableStateOf(true) }
    val key = stringPreferencesKey("entries")
    LaunchedEffect(Unit) {
        val raw = context.dataStore.data.first()[key]
        if (!raw.isNullOrBlank()) {
            val arr = JSONArray(raw)
            entries = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Entry(o.getLong("id"), o.getString("title"), o.getDouble("amount"), o.getString("type"), o.getString("category"), o.getString("payment"))
            }
        }
        loaded = true
    }
    fun persist(list: List<Entry>) {
        scope.launch {
            val arr = JSONArray()
            list.forEach { e -> arr.put(JSONObject().put("id", e.id).put("title", e.title).put("amount", e.amount).put("type", e.type).put("category", e.category).put("payment", e.payment)) }
            context.dataStore.edit { it[key] = arr.toString() }
        }
    }
    val income = entries.filter { it.type == "Income" }.sumOf { it.amount }
    val expense = entries.filter { it.type == "Expense" }.sumOf { it.amount }
    val bn = bengali
    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Gold, background = Color(0xFFF5F6FA))) {
        Scaffold(topBar = { TopAppBar(title = { Text("My Daily Hisab", color = Color.White, fontWeight = FontWeight.Bold) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy), actions = { TextButton(onClick = { bengali = !bengali }) { Text(if (bn) "EN" else "বাংলা", color = Gold) } }) },
            floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }, containerColor = Gold, contentColor = Navy) { Icon(Icons.Default.Add, contentDescription = "Add") } }) { pad ->
            Column(Modifier.fillMaxSize().background(Color(0xFFF5F6FA)).padding(pad).padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SummaryCard(if (bn) "আয়" else "Income", income, Income, Modifier.weight(1f))
                    SummaryCard(if (bn) "খরচ" else "Expense", expense, Expense, Modifier.weight(1f))
                }
                Card(Modifier.fillMaxWidth().padding(top = 12.dp), colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(if (bn) "বর্তমান ব্যালেন্স" else "Current Balance", color = Color.LightGray)
                        Text("₹${"%.2f".format(income - expense)}", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Text(if (bn) "লেনদেনের ইতিহাস" else "Transaction History", Modifier.padding(top = 20.dp, bottom = 8.dp), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Navy)
                if (!loaded || entries.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(if (bn) "এখনও কোনো হিসাব নেই। + চাপ দিয়ে যোগ করো।" else "No entries yet. Tap + to add one.", color = Color.Gray) }
                else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(entries.sortedByDescending { it.id }, key = { it.id }) { e ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(e.title, fontWeight = FontWeight.SemiBold, color = Navy)
                                    Text("${e.category} • ${e.payment}", color = Color.Gray, fontSize = 12.sp)
                                }
                                Text((if (e.type == "Income") "+" else "−") + "₹${"%.2f".format(e.amount)}", color = if (e.type == "Income") Income else Expense, fontWeight = FontWeight.Bold)
                                IconButton(onClick = { entries = entries.filterNot { it.id == e.id }; persist(entries) }) { Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray) }
                            }
                        }
                    }
                }
            }
        }
        if (showAdd) AlertDialog(onDismissRequest = { showAdd = false }, title = { Text(if (bn) "নতুন হিসাব" else "New Entry") }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(selected = type == "Income", onClick = { type = "Income" }, label = { Text(if (bn) "আয়" else "Income") }); FilterChip(selected = type == "Expense", onClick = { type = "Expense" }, label = { Text(if (bn) "খরচ" else "Expense") }) }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text(if (bn) "বিবরণ (অবশ্যই)" else "Description (required)") }, singleLine = true)
                OutlinedTextField(value = amount, onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text(if (bn) "টাকার পরিমাণ" else "Amount") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                Text(if (bn) "ক্যাটাগরি" else "Category")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Food", "Travel", "Bill", "Salary", "Other").forEach { FilterChip(selected = category == it, onClick = { category = it }, label = { Text(it) }) } }
                Text(if (bn) "পেমেন্ট" else "Payment")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Cash", "Digital").forEach { FilterChip(selected = payment == it, onClick = { payment = it }, label = { Text(it) }) } }
            }
        }, confirmButton = { TextButton(onClick = {
            val v = amount.toDoubleOrNull()
            if (title.isNotBlank() && v != null && v > 0) { val updated = entries + Entry(System.currentTimeMillis(), title.trim(), v, type, category, payment); entries = updated; persist(updated); title = ""; amount = ""; showAdd = false }
        }) { Text(if (bn) "সেভ" else "Save") } }, dismissButton = { TextButton(onClick = { showAdd = false }) { Text(if (bn) "বাতিল" else "Cancel") } })
    }
}

@Composable
fun SummaryCard(label: String, value: Double, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) { Text(label, color = Color.Gray); Text("₹${"%.2f".format(value)}", color = color, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
    }
}
